var a = 10;
let b = 20;

console.log(a);
console.log(b);

function test() {
  var c = 30;
  console.log(c);
}
test();
