sayHello();
function sayHello() {
  console.log("Hello");
}

sayHi();
var sayHi = function () {
  console.log("Hi");
};
